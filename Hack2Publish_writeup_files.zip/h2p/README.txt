Hack2Publish — TartanIMU Challenge (IROS 2026) — writeup attachments
===================================================================

Team: Md. Hamid Hosen, Esfer Sami, Kahakashan Ashraf, Foysal Emon Shanto
Ranked Kaggle submission: 56402554  (public 0.28609, official full-test 0.21903)

Contents
--------
Hack2Publish_TartanIMU_report.pdf     technical report (method, ablations, data findings,
                                      compliance declaration, all 89 per-sequence results)
submission_final_kaggle_w_uni.csv     the ranked prediction file, md5 fd12d4f25d7b52d44aaa4e4a14534378
final_kaggle_w_uni_per_sequence.csv   official scoring-service output (ATE20 / AVE / RTE per sequence)
final_kaggle_w_uni_swa.pt             the ranked checkpoint, 3.9 M parameters, one shared weight set
                                      sha256 69764745d0589eba846d571b364aa3d33fe6a25be5e516879339b3231ceeb9b1
                                      md5    737c12af68ea4ad6aa419a72e92bad4d
final_kaggle_w_uni.json               the exact training configuration of that checkpoint
infer.py, model.py, requirements.txt  inference entry point (reads only the test IMU + window index CSV)

Reproduce the submission
------------------------
  pip install -r requirements.txt
  python infer.py --traj_dir /path/to/test --windows /path/to/index/test_windows.csv \
                  --checkpoint final_kaggle_w_uni_swa.pt --out submission.csv

Full training code and analysis:
  https://github.com/hamidhosen42/TartanIMU-Challenge-Multi-Platform-Inertial-Odometry
Weights and model card:
  https://huggingface.co/mdhamidhosen/tartanimu-unified-hosen42
